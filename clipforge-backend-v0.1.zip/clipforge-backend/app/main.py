from __future__ import annotations
import os, uuid, shutil, subprocess, threading, re
from pathlib import Path
from typing import Any
from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

ROOT = Path(os.getenv('DATA_DIR', '/tmp/clipforge-data'))
UPLOADS = ROOT / 'uploads'
OUTPUTS = ROOT / 'outputs'
for p in (UPLOADS, OUTPUTS): p.mkdir(parents=True, exist_ok=True)
MAX_BYTES = int(os.getenv('MAX_UPLOAD_MB', '500')) * 1024 * 1024
ALLOWED = {'.mp4', '.mov', '.mkv', '.webm', '.m4v'}
JOBS: dict[str, dict[str, Any]] = {}
LOCK = threading.Lock()

app = FastAPI(title='ClipForge AI API', version='0.1.0')
origins = [x.strip() for x in os.getenv('CORS_ORIGINS', '*').split(',') if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False,
                   allow_methods=['GET', 'POST', 'OPTIONS'], allow_headers=['*'])


def run(cmd: list[str]) -> None:
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode:
        raise RuntimeError((result.stderr or 'Command failed')[-2500:])


def duration_seconds(path: Path) -> float:
    out = subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)], text=True)
    return max(0.0, float(out.strip()))


def rank_windows(segments: list[dict], total: float, count: int) -> list[tuple[float,float,str]]:
    # First MVP: transcript-based heuristic ranking, not a promise of virality.
    candidates = []
    for i, seg in enumerate(segments):
        start = float(seg['start']); end = float(seg['end'])
        if end - start < 1: continue
        phrase = str(seg['text']).strip()
        words = re.findall(r"[\w']+", phrase)
        score = min(len(words), 24) / 24
        score += 0.45 * bool(re.search(r'\?|!|\b(why|how|secret|never|best|worst|shocking|mistake|truth|impossible|important)\b', phrase, re.I))
        score += 0.25 * bool(re.search(r'\b(but|because|actually|however|then)\b', phrase, re.I))
        center = (start + end) / 2
        a = max(0, center - 18); b = min(total, center + 22)
        if b - a < 12: continue
        candidates.append((score, a, b, phrase))
    candidates.sort(reverse=True)
    selected = []
    for score, a, b, phrase in candidates:
        if all(b <= x[0] or a >= x[1] for x in selected):
            selected.append((a,b,phrase))
        if len(selected) >= count: break
    if len(selected) < count:
        # Fill remaining slots with evenly spaced windows if transcript is sparse.
        span = min(40.0, max(12.0, total / max(count,1)))
        for n in range(count * 3):
            a = max(0, (total - span) * n / max(1, count * 3 - 1)); b = min(total, a + span)
            if b-a >= 12 and all(b <= x[0] or a >= x[1] for x in selected):
                selected.append((a,b,'Selected from an evenly spaced section'))
            if len(selected) >= count: break
    return sorted(selected[:count], key=lambda x:x[0])


def srt_time(seconds: float) -> str:
    ms = int(max(0, seconds) * 1000)
    h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f'{h:02}:{m:02}:{s:02},{ms:03}'


def process_job(job_id: str, source: Path, count: int) -> None:
    job = JOBS[job_id]
    try:
        job['status'] = 'transcribing'
        from faster_whisper import WhisperModel
        model_name = os.getenv('WHISPER_MODEL', 'base')
        model = WhisperModel(model_name, device='cpu', compute_type='int8')
        segments_iter, info = model.transcribe(str(source), task='translate', vad_filter=True, word_timestamps=False)
        segments = [{'start': float(s.start), 'end': float(s.end), 'text': s.text.strip()} for s in segments_iter]
        if not segments: raise RuntimeError('No speech was detected. Try a video with clear speech.')
        total = duration_seconds(source)
        windows = rank_windows(segments, total, count)
        if not windows: raise RuntimeError('Could not find suitable clip sections in this video.')
        job['status'] = 'rendering'; job['clips'] = []
        out_dir = OUTPUTS / job_id; out_dir.mkdir(parents=True, exist_ok=True)
        for idx, (start, end, reason) in enumerate(windows, 1):
            srt = out_dir / f'clip-{idx}.srt'
            lines=[]; n=1
            for seg in segments:
                a=max(float(seg['start']), start); b=min(float(seg['end']), end)
                if b <= a: continue
                lines += [str(n), f'{srt_time(a-start)} --> {srt_time(b-start)}', seg['text'], '']; n+=1
            srt.write_text('\n'.join(lines), encoding='utf-8')
            out = out_dir / f'clip-{idx}.mp4'
            # 9:16 center crop, burned English translated subtitles.
            srt_arg = str(srt).replace('\\', '/').replace(':', r'\:').replace("'", r"\'")
            vf = f"scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,subtitles='{srt_arg}':force_style='FontName=Arial,FontSize=16,Outline=2,Shadow=1,Alignment=2,MarginV=100'"
            run(['ffmpeg','-y','-ss',str(start),'-i',str(source),'-t',str(end-start),'-vf',vf,'-c:v','libx264','-preset','veryfast','-crf','24','-c:a','aac','-b:a','128k','-movflags','+faststart',str(out)])
            job['clips'].append({'number':idx,'start':round(start,2),'end':round(end,2),'reason':reason,'download_url':f"/api/jobs/{job_id}/clips/{idx}"})
        job['status']='completed'; job['message']='Clips are ready.'
    except Exception as e:
        job['status']='failed'; job['error']=str(e)[:1200]
    finally:
        try: source.unlink(missing_ok=True)
        except Exception: pass


@app.get('/')
def home(): return {'name':'ClipForge AI API','version':'0.1.0','status':'ok'}

@app.get('/health')
def health(): return {'ok':True}

@app.post('/api/jobs')
async def create_job(background_tasks: BackgroundTasks, video: UploadFile = File(...), clips: int = 4):
    if clips not in (3,4,5): raise HTTPException(400, 'clips must be 3, 4, or 5')
    suffix=Path(video.filename or '').suffix.lower()
    if suffix not in ALLOWED: raise HTTPException(400, 'Upload MP4, MOV, MKV, WEBM, or M4V video.')
    job_id=uuid.uuid4().hex
    dest=UPLOADS / f'{job_id}{suffix}'
    size=0
    try:
        with dest.open('wb') as f:
            while True:
                chunk=await video.read(1024*1024)
                if not chunk: break
                size += len(chunk)
                if size > MAX_BYTES: raise HTTPException(413, f'Max upload size is {MAX_BYTES//(1024*1024)} MB')
                f.write(chunk)
    except Exception:
        dest.unlink(missing_ok=True); raise
    JOBS[job_id]={'id':job_id,'status':'queued','clips':[],'message':'Upload received. Processing will start shortly.'}
    background_tasks.add_task(process_job, job_id, dest, clips)
    return {'job_id':job_id,'status':'queued','status_url':f'/api/jobs/{job_id}'}

@app.get('/api/jobs/{job_id}')
def job_status(job_id: str):
    job=JOBS.get(job_id)
    if not job: raise HTTPException(404,'Job not found. Jobs are temporary in this MVP.')
    return job

@app.get('/api/jobs/{job_id}/clips/{clip_number}')
def download_clip(job_id: str, clip_number: int):
    if job_id not in JOBS or JOBS[job_id].get('status') != 'completed': raise HTTPException(404,'Clip not ready')
    path=OUTPUTS/job_id/f'clip-{clip_number}.mp4'
    if not path.exists(): raise HTTPException(404,'Clip not found')
    return FileResponse(path, media_type='video/mp4', filename=f'clipforge-{clip_number}.mp4')
