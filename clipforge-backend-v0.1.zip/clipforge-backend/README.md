# ClipForge AI Backend — MVP v0.1

This is the first upload-based backend milestone for the ClipForge AI frontend.
It accepts a video file, translates speech to English with faster-whisper, ranks
candidate moments using a transparent transcript heuristic, and renders vertical
9:16 MP4 clips with burned-in English subtitles using FFmpeg.

## Important limitations
- This is an MVP, not production-ready: in-memory jobs, temporary local storage,
  no login, no persistent database, no queue, no billing, and no automatic cleanup.
- The first clip ranker is a transcript heuristic, not a trained virality predictor.
- Hosting free tiers may sleep, restart, limit CPU/RAM, and delete local files.
  Whisper model downloads and video rendering can be slow or exceed free quotas.
- Only upload videos you own or are authorized to process. No platform scraping,
  login bypass, DRM bypass, or access-control circumvention.
- Frontend still needs to be connected to this API URL after deployment.

## Deploy
Deploy this folder as a Docker web service on a host that supports Docker and
background processing. `render.yaml` is a starting blueprint, not a guarantee
that video/Whisper processing will fit a provider's free plan. Set `CORS_ORIGINS`
to the exact GitHub Pages origin and use persistent storage for real use.

## API
- `GET /health`
- `POST /api/jobs` multipart form: `video` file and `clips` integer (3, 4, or 5)
- `GET /api/jobs/{job_id}` to poll status
- `GET /api/jobs/{job_id}/clips/{clip_number}` to download a completed MP4

Example:
```bash
curl -F 'video=@my-video.mp4' -F 'clips=4' https://YOUR-API/api/jobs
```
